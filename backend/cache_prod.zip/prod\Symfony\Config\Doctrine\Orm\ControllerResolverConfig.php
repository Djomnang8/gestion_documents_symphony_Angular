<?php

namespace Symfony\Config\Doctrine\Orm;

use Symfony\Component\Config\Loader\ParamConfigurator;
use Symfony\Component\Config\Definition\Exception\InvalidConfigurationException;

/**
 * This class is automatically generated to help in creating a config.
 */
class ControllerResolverConfig 
{
    private $enabled;
    private $autoMapping;
    private $evictCache;
    private $_usedProperties = [];

    /**
     * @default true
     * @param ParamConfigurator|bool $value
     * @return $this
     */
    public function enabled($value): static
    {
        $this->_usedProperties['enabled'] = true;
        $this->enabled = $value;

        return $this;
    }

    /**
     * Set to true to enable using route placeholders as lookup criteria when the primary key doesn't match the argument name
     * @default false
     * @param ParamConfigurator|bool $value
     * @deprecated Since doctrine/doctrine-bundle 3.1: The "doctrine.orm.controller_resolver.auto_mapping" option is deprecated and will be removed in DoctrineBundle 4.0, as it only accepts `false` since 3.0.
     * @return $this
     */
    public function autoMapping($value): static
    {
        $this->_usedProperties['autoMapping'] = true;
        $this->autoMapping = $value;

        return $this;
    }

    /**
     * Set to true to fetch the entity from the database instead of using the cache, if any
     * @default false
     * @param ParamConfigurator|bool $value
     * @return $this
     */
    public function evictCache($value): static
    {
        $this->_usedProperties['evictCache'] = true;
        $this->evictCache = $value;

        return $this;
    }

    public function __construct(array $config = [])
    {
        if (array_key_exists('enabled', $config)) {
            $this->_usedProperties['enabled'] = true;
            $this->enabled = $config['enabled'];
            unset($config['enabled']);
        }

        if (array_key_exists('auto_mapping', $config)) {
            $this->_usedProperties['autoMapping'] = true;
            $this->autoMapping = $config['auto_mapping'];
            unset($config['auto_mapping']);
        }

        if (array_key_exists('evict_cache', $config)) {
            $this->_usedProperties['evictCache'] = true;
            $this->evictCache = $config['evict_cache'];
            unset($config['evict_cache']);
        }

        if ($config) {
            throw new InvalidConfigurationException(sprintf('The following keys are not supported by "%s": ', __CLASS__).implode(', ', array_keys($config)));
        }
    }

    public function toArray(): array
    {
        $output = [];
        if (isset($this->_usedProperties['enabled'])) {
            $output['enabled'] = $this->enabled;
        }
        if (isset($this->_usedProperties['autoMapping'])) {
            $output['auto_mapping'] = $this->autoMapping;
        }
        if (isset($this->_usedProperties['evictCache'])) {
            $output['evict_cache'] = $this->evictCache;
        }

        return $output;
    }

}
